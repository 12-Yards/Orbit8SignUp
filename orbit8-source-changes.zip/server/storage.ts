import {
  type User, type InsertUser,
  type Registration, type InsertRegistration,
  type ContactSubmission, type InsertContact,
  users, registrations, contactSubmissions,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, or } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createRegistration(reg: InsertRegistration): Promise<Registration>;
  getRegistrations(): Promise<Registration[]>;
  getRegistration(id: number): Promise<Registration | undefined>;
  updateRegistration(id: number, data: Partial<InsertRegistration>): Promise<Registration | undefined>;
  createContact(contact: InsertContact): Promise<ContactSubmission>;
  getContacts(): Promise<ContactSubmission[]>;
  getContact(id: number): Promise<ContactSubmission | undefined>;
  checkDomainExists(domainName: string): Promise<boolean>;
  checkEmailExists(email: string): Promise<boolean>;
  markRegistrationRead(id: number): Promise<Registration | undefined>;
  markContactRead(id: number): Promise<ContactSubmission | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async createRegistration(reg: InsertRegistration): Promise<Registration> {
    const [result] = await db.insert(registrations).values(reg).returning();
    return result;
  }

  async getRegistrations(): Promise<Registration[]> {
    return db.select().from(registrations).orderBy(desc(registrations.createdAt));
  }

  async getRegistration(id: number): Promise<Registration | undefined> {
    const [result] = await db.select().from(registrations).where(eq(registrations.id, id));
    return result;
  }

  async updateRegistration(id: number, data: Partial<InsertRegistration>): Promise<Registration | undefined> {
    const [result] = await db.update(registrations).set(data).where(eq(registrations.id, id)).returning();
    return result;
  }

  async createContact(contact: InsertContact): Promise<ContactSubmission> {
    const [result] = await db.insert(contactSubmissions).values(contact).returning();
    return result;
  }

  async getContacts(): Promise<ContactSubmission[]> {
    return db.select().from(contactSubmissions).orderBy(desc(contactSubmissions.createdAt));
  }

  async getContact(id: number): Promise<ContactSubmission | undefined> {
    const [result] = await db.select().from(contactSubmissions).where(eq(contactSubmissions.id, id));
    return result;
  }

  async checkEmailExists(email: string): Promise<boolean> {
    const results = await db.select().from(registrations).where(eq(registrations.email, email));
    return results.length > 0;
  }

  async checkDomainExists(domainName: string): Promise<boolean> {
    const results = await db.select().from(registrations).where(
      or(
        eq(registrations.domainName, domainName),
        eq(registrations.noDomainPrefix, domainName)
      )
    );
    return results.length > 0;
  }

  async markRegistrationRead(id: number): Promise<Registration | undefined> {
    const [result] = await db.update(registrations).set({ isRead: true }).where(eq(registrations.id, id)).returning();
    return result;
  }

  async markContactRead(id: number): Promise<ContactSubmission | undefined> {
    const [result] = await db.update(contactSubmissions).set({ isRead: true }).where(eq(contactSubmissions.id, id)).returning();
    return result;
  }
}

export const storage = new DatabaseStorage();
